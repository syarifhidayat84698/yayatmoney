@extends('templates.app')

@section('title', ' Pemasukan ')

@section('content')
{{-- Konten Apapun Selalu diisi disini --}}

<div class="container mt-5">
    <div class="row">
        <div class="col-md-4 mb-3">
           <h1>Piutang</h1>
        </div>
    </div>
    <div class="row">
        <form>
            <div class="mb-3">
                <label for="pihakBerhutang" class="form-label">Pihak yang Berhutang</label>
                <input type="text" class="form-control" id="pihakBerhutang" placeholder="Masukkan nama pihak yang berhutang" required>
            </div>
            <div class="mb-3">
                <label for="jumlahPiutang" class="form-label">Jumlah Piutang</label>
                <input type="number" class="form-control" id="jumlahPiutang" placeholder="Masukkan jumlah piutang" required>
            </div>
            <div class="mb-3">
                <label for="tanggalJatuhTempo" class="form-label">Tanggal Jatuh Tempo</label>
                <input type="date" class="form-control" id="tanggalJatuhTempo" required>
            </div>
            <div class="mb-3">
                <label for="pengingat" class="form-label">Pengingat Pembayaran</label>
                <input type="date" class="form-control" id="pengingat">
            </div>
            <button type="submit" class="btn btn-success">Simpan Piutang</button>
        </form>
    </div>
    <div class="row mt-4">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Pihak yang Berhutang</th>
                <th scope="col">Jumlah Piutang</th>
                <th scope="col">Tanggal Jatuh Tempo</th>
                <th scope="col">Pengingat</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>John Doe</td>
                <td>Rp 5.000.000</td>
                <td>2024-01-10</td>
                <td>2024-01-05</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jane Smith</td>
                <td>Rp 3.000.000</td>
                <td>2024-02-15</td>
                <td>2024-02-10</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Perusahaan ABC</td>
                <td>Rp 10.000.000</td>
                <td>2024-03-20</td>
                <td>2024-03-15</td>
              </tr>
            </tbody>
          </table>
    </div>
</div>


@endsection
