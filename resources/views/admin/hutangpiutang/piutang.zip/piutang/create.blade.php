@extends('templates.app')

@section('title', 'Tambah Transaksi')

@section('content')
{{-- Konten Apapun Selalu diisi disini --}}
<div class="container mt-5">
    <h2 class="mb-4">Tambah Pemasukan</h2>
    <form>
        <div class="mb-3">
            <label for="transactionName" class="form-label">Nama Transaksi</label>
            <input type="text" class="form-control" id="transactionName" placeholder="Masukkan nama transaksi">
        </div>
        <div class="mb-3">
            <label for="amount" class="form-label">Jumlah</label>
            <input type="number" class="form-control" id="amount" placeholder="Masukkan jumlah">
        </div>
        <div class="mb-3">
            <label for="date" class="form-label">Tanggal</label>
            <input type="date" class="form-control" id="date">
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi</label>
            <textarea class="form-control" id="description" rows="3" placeholder="Masukkan deskripsi"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Transaksi</button>
    </form>
</div>

@endsection
